HR POLICY AGENT - BEGINNER STARTER

WHAT THIS PROJECT DOES
- Accepts an employee HR-policy question.
- Searches local policy text files.
- If OPENAI_API_KEY is configured, uses an LLM to answer only from retrieved policy evidence.
- Escalates low-evidence and sensitive questions to a human review queue.
- Stores review decisions and basic request logs in SQLite.
- Provides /health endpoint.

IMPORTANT
The policy document in policies/ is SAMPLE DEMO TEXT, not a real company's policy.
Do not use real employee personal data. Replace the sample text with an approved, non-sensitive policy document.
Without an API key, the app runs in retrieval-only demo mode and explicitly marks cases for review. That mode is not an LLM implementation.

WINDOWS / PYCHARM SETUP
1. Extract the ZIP.
2. Open the extracted hr_policy_agent_starter folder in PyCharm.
3. Open the PyCharm Terminal.
4. Create a virtual environment:
   python -m venv .venv
5. Activate it:
   .venv\Scripts\activate
6. Install packages:
   pip install -r requirements.txt
7. Optional LLM setup:
   - Copy .env.example to a file named .env
   - Add your API key after OPENAI_API_KEY=
   - Keep .env private; never upload it or share screenshots showing the key.
   - API usage may incur charges. Check your provider's pricing and account limits.
8. Run:
   python app.py
9. Open in browser:
   http://127.0.0.1:5000
10. Ask: "How do I request casual leave?"
11. Open the review queue:
   http://127.0.0.1:5000/reviews
12. Health check:
   http://127.0.0.1:5000/health

HOW TO DEMONSTRATE
A. Normal query: "How do I request casual leave?"
B. Missing exact policy detail: "What is the exact annual leave carry-forward limit?"
C. Sensitive query: "I want to report harassment."
D. Show the review queue and approve/correct/reject a case.
E. Failure test: temporarily rename the policies folder, restart the app, submit a question, capture the controlled error, then restore the folder.

WHAT TO ADD FOR YOUR SUBMISSION
- Screenshots of the running app, a grounded response, the review queue, and health endpoint.
- Actual measured response times and real pass/fail test outcomes.
- Your own approved HR policy document.
- Source code and a short explanation of the retrieval and escalation logic.

NOTE
This is a classroom prototype, not a production HR system. It has no authentication, role-based access control, encryption, or production-grade security. Do not deploy it publicly or use it for real employee decisions.

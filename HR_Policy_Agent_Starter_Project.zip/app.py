import os, re, sqlite3, time, uuid
from datetime import datetime
from flask import Flask, render_template, request, redirect, url_for, flash
from dotenv import load_dotenv

load_dotenv()
app = Flask(__name__)
app.secret_key = os.getenv("FLASK_SECRET", "change-this-local-demo-key")
DB = "hr_agent.db"

def init_db():
    with sqlite3.connect(DB) as con:
        con.execute("""CREATE TABLE IF NOT EXISTS reviews (
            id TEXT PRIMARY KEY, question TEXT, draft TEXT, source TEXT,
            status TEXT, reviewer_note TEXT, created_at TEXT)""")
        con.execute("""CREATE TABLE IF NOT EXISTS logs (
            id TEXT PRIMARY KEY, question TEXT, status TEXT, latency REAL,
            created_at TEXT)""")

def load_policy_chunks():
    chunks = []
    folder = "policies"
    for name in os.listdir(folder):
        if name.lower().endswith(".txt"):
            path = os.path.join(folder, name)
            with open(path, "r", encoding="utf-8") as f:
                text = f.read()
            for part in re.split(r"\n\s*\n", text):
                part = part.strip()
                if part:
                    chunks.append((name, part))
    return chunks

def retrieve(question):
    # Simple transparent keyword retrieval for a beginner-friendly prototype.
    terms = set(re.findall(r"[a-zA-Z]{3,}", question.lower()))
    ranked = []
    for filename, chunk in load_policy_chunks():
        words = set(re.findall(r"[a-zA-Z]{3,}", chunk.lower()))
        score = len(terms & words) / max(len(terms), 1)
        if score > 0:
            ranked.append((score, filename, chunk))
    ranked.sort(reverse=True)
    return ranked[:3]

def draft_answer(question, results):
    if not results or results[0][0] < 0.12:
        return ("I could not find sufficiently relevant information in the available HR policy "
                "documents. Please contact HR for confirmation."), "No reliable policy evidence", True

    evidence = "\n\n".join(
        f"Source: {filename}\nPolicy text: {chunk}" for _, filename, chunk in results
    )
    source_names = ", ".join(sorted(set(x[1] for x in results)))

    api_key = os.getenv("OPENAI_API_KEY")
    if api_key:
        try:
            from openai import OpenAI
            client = OpenAI(api_key=api_key)
            response = client.responses.create(
                model=os.getenv("OPENAI_MODEL", "gpt-5.5"),
                instructions=(
                    "You are an HR policy assistant. Answer ONLY using the supplied policy evidence. "
                    "Do not invent policy rules, dates, amounts, or entitlements. If evidence is incomplete "
                    "or conflicting, say so and recommend HR review. Do not make employment decisions. "
                    "Keep the answer concise and mention the source filename."
                ),
                input=f"Employee question: {question}\n\nPolicy evidence:\n{evidence}"
            )
            answer = response.output_text.strip()
            # Conservative escalation for high-risk / uncertain categories.
            risk_words = ["termination", "harassment", "discrimination", "salary", "payroll",
                          "disciplinary", "medical", "maternity", "legal", "complaint"]
            needs_review = any(w in question.lower() for w in risk_words) or \
                           any(w in answer.lower() for w in ["not specified", "unclear", "conflicting", "cannot determine"])
            return answer, source_names, needs_review
        except Exception as e:
            return ("The language-model service is currently unavailable. No AI answer was generated. "
                    "Please retry or contact HR."), f"LLM/API error: {type(e).__name__}", True

    # Safe demo mode when no API key is configured: returns retrieved policy text, not an LLM answer.
    answer = "I found the following relevant policy text:\n\n" + results[0][2]
    return answer, source_names + " (retrieval-only demo; configure an API key for LLM answers)", True

@app.route("/", methods=["GET", "POST"])
def index():
    answer = source = None
    needs_review = False
    latency = None
    if request.method == "POST":
        question = request.form.get("question", "").strip()
        start = time.time()
        req_id = str(uuid.uuid4())[:8]
        if not question:
            flash("Please enter a question.")
        else:
            try:
                results = retrieve(question)
                answer, source, needs_review = draft_answer(question, results)
                status = "Escalated for HR review" if needs_review else "Answered"
                if needs_review:
                    with sqlite3.connect(DB) as con:
                        con.execute("INSERT INTO reviews VALUES (?, ?, ?, ?, ?, ?, ?)",
                            (req_id, question, answer, source, "Pending", "",
                             datetime.now().isoformat(timespec="seconds")))
                latency = round(time.time() - start, 3)
                with sqlite3.connect(DB) as con:
                    con.execute("INSERT INTO logs VALUES (?, ?, ?, ?, ?)",
                        (req_id, question, status, latency,
                         datetime.now().isoformat(timespec="seconds")))
            except Exception as e:
                answer = "A system error occurred. Please retry or contact HR."
                source = type(e).__name__
                needs_review = True
                latency = round(time.time() - start, 3)
    return render_template("index.html", answer=answer, source=source,
                           needs_review=needs_review, latency=latency)

@app.route("/reviews")
def reviews():
    with sqlite3.connect(DB) as con:
        con.row_factory = sqlite3.Row
        rows = con.execute("SELECT * FROM reviews ORDER BY created_at DESC").fetchall()
    return render_template("reviews.html", rows=rows)

@app.route("/review/<review_id>", methods=["POST"])
def review_action(review_id):
    status = request.form.get("status", "Pending")
    note = request.form.get("note", "")
    if status not in ["Approved", "Corrected", "Rejected"]:
        flash("Invalid review decision.")
    else:
        with sqlite3.connect(DB) as con:
            con.execute("UPDATE reviews SET status=?, reviewer_note=? WHERE id=?",
                        (status, note, review_id))
        flash(f"Review marked {status}.")
    return redirect(url_for("reviews"))

@app.route("/health")
def health():
    return {"status": "ok", "service": "HR Policy Agent"}

if __name__ == "__main__":
    init_db()
    app.run(host="127.0.0.1", port=5000, debug=True)
